package mods.HerobrineMod.common;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public final class EntityHerobrine extends EntityBaseHMod {
    private int attackCooldown;
    public EntityHerobrine(EntityType<? extends EntityBaseHMod> t,Level l){super(t,l);setNoGravity(true);}
    @Override protected void registerGoals(){super.registerGoals();targetSelector.addGoal(1,new NearestAttackableTargetGoal<>(this,Player.class,true));}
    @Override protected void customServerAiStep(){super.customServerAiStep();setDeltaMovement(getDeltaMovement().scale(.92D));if(attackCooldown>0)attackCooldown--;var p=level().getNearestPlayer(this,24D);if(p!=null){getLookControl().setLookAt(p,30F,30F);if(attackCooldown==0&&distanceToSqr(p)<324){HerobrineStalker.Lightning(level(),p);attackCooldown=100;}}}
    @Override public void tick(){super.tick();if(level().isClientSide)level().addParticle(ParticleTypes.WHITE_ASH,getX(),getY()+1,getZ(),0,.01,0);}
}
