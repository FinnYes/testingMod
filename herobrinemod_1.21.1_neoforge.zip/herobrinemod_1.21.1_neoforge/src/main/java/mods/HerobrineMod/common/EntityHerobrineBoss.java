package mods.HerobrineMod.common;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public final class EntityHerobrineBoss extends Monster {
    public EntityHerobrineBoss(EntityType<? extends Monster> t,Level l){super(t,l);setPersistenceRequired();}
    @Override protected void registerGoals(){goalSelector.addGoal(1,new MeleeAttackGoal(this,1.1D,true));targetSelector.addGoal(1,new NearestAttackableTargetGoal<>(this,Player.class,true));}
}
