package mods.HerobrineMod.common;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;

public final class HerobrineStalker {
    private HerobrineStalker(){}
    public static void spawn(Level level,EntityType<?> type,BlockPos pos){if(level.isClientSide)return;Entity e=type.create(level);if(e==null)return;e.moveTo(pos.getX()+.5,pos.getY(),pos.getZ()+.5,level.random.nextFloat()*360F,0);level.addFreshEntity(e);}
    public static void freeze(Player p,int seconds){p.addEffect(new MobEffectInstance(MobEffects.SLOWNESS,seconds*20,5));p.addEffect(new MobEffectInstance(MobEffects.DARKNESS,seconds*10,0));}
    public static void randomScare(EntityStalker s,Player p){switch(s.random.nextInt(10)){case 0->Lightning(s.level(),p);case 1->onFire(p);case 2->placeWater(p);case 3->placeLava(p);case 4->breakglass(s.level(),p.blockPosition());case 5->Zombie(s.level(),p.blockPosition());case 6->Chicken(s.level(),p.blockPosition());case 7->HVillager(s.level(),p.blockPosition());case 8->potion(p);default->RingOfFire(s.level(),p.blockPosition());}}
    public static void blastGlowe(Level level,BlockPos pos){if(!(level instanceof ServerLevel server))return;server.sendParticles(ParticleTypes.EXPLOSION,pos.getX()+.5,pos.getY()+1,pos.getZ()+.5,1,0,0,0,0);server.sendParticles(ParticleTypes.GLOW,pos.getX()+.5,pos.getY()+1,pos.getZ()+.5,12,.3,.4,.3,.02);level.playSound(null,pos,SoundEvents.LIGHTNING_BOLT_THUNDER,SoundSource.HOSTILE,.5F,1.7F);}
    public static void Lightning(Level level,Entity target){if(level.isClientSide)return;var bolt=EntityType.LIGHTNING_BOLT.create(level);if(bolt==null)return;bolt.moveTo(target.getX(),target.getY(),target.getZ());level.addFreshEntity(bolt);}
    public static void dropTorches(Level level,BlockPos pos){if(!(level instanceof ServerLevel server))return;for(int i=0;i<3;i++)server.addFreshEntity(new ItemEntity(server,pos.getX()+.5+level.random.nextInt(5)-2,pos.getY()+.5,pos.getZ()+.5+level.random.nextInt(5)-2,new ItemStack(Items.TORCH)));}
    public static void cutLeaves(Level level,BlockPos o){if(!(level instanceof ServerLevel s))return;BlockPos.betweenClosed(o.offset(-3,-1,-3),o.offset(3,4,3)).forEach(p->{if(s.getBlockState(p).is(net.minecraft.tags.BlockTags.LEAVES))s.destroyBlock(p,false);});}
    public static void breakglass(Level level,BlockPos o){if(!(level instanceof ServerLevel s))return;BlockPos.betweenClosed(o.offset(-3,-2,-3),o.offset(3,3,3)).forEach(p->{if(s.getBlockState(p).is(net.minecraft.tags.BlockTags.IMPERMEABLE))s.destroyBlock(p,false);});}
    public static void onFire(Player p){if(HerobrineMod.CONFIG.setPlayerOnFire.get()==1)p.setSecondsOnFire(6);}
    public static void throwplayer2(Player p,Entity source,double power){throwplayer(p,source,power);}
    public static void throwplayer(Player p,Entity source,double power){double dx=p.getX()-source.getX(),dz=p.getZ()-source.getZ(),len=Math.max(.1D,Math.sqrt(dx*dx+dz*dz));p.push(dx/len*power,.5D,dz/len*power);p.hurtMarked=true;}
    public static void potion(Player p){p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS,80,0));p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS,120,0));}
    public static void dropItems(Level level,BlockPos pos){if(level instanceof ServerLevel s)s.addFreshEntity(new ItemEntity(s,pos.getX()+.5,pos.getY()+1,pos.getZ()+.5,new ItemStack(Items.ROTTEN_FLESH)));}
    public static void RingOfFire(Level level,BlockPos c){if(!(level instanceof ServerLevel s)||HerobrineMod.CONFIG.placeFire.get()!=1)return;for(int i=0;i<16;i++){double a=i*Math.PI*2/16.0;BlockPos p=BlockPos.containing(c.getX()+Math.cos(a)*3,c.getY(),c.getZ()+Math.sin(a)*3);if(s.isEmptyBlock(p)&&s.getBlockState(p.below()).isFaceSturdy(s,p.below(),net.minecraft.core.Direction.UP))s.setBlock(p,Blocks.FIRE.defaultBlockState(),3);}}
    public static void RingOfFireH(Level l,BlockPos p){RingOfFire(l,p);}
    public static void RingOfEnemies(Level l,BlockPos p){for(int i=0;i<6;i++)Zombie(l,p.offset(l.random.nextInt(7)-3,0,l.random.nextInt(7)-3));}
    public static void placeWater(Player p){if(HerobrineMod.CONFIG.placeWater.get()==1){BlockPos q=p.blockPosition().relative(p.getDirection());if(p.level().isEmptyBlock(q))p.level().setBlock(q,Blocks.WATER.defaultBlockState(),3);}}
    public static void placeLava(Player p){if(HerobrineMod.CONFIG.placeLava.get()==1){BlockPos q=p.blockPosition().relative(p.getDirection());if(p.level().isEmptyBlock(q))p.level().setBlock(q,Blocks.LAVA.defaultBlockState(),3);}}
    public static void Zombie(Level l,BlockPos p){spawn(l,ModEntities.ZOMBIE.get(),p);} public static void Chicken(Level l,BlockPos p){spawn(l,ModEntities.CHICKEN.get(),p);} public static void HVillager(Level l,BlockPos p){spawn(l,ModEntities.HVILLAGER.get(),p);} public static void Boss(Level l,BlockPos p){spawn(l,ModEntities.BOSS.get(),p);}
}
