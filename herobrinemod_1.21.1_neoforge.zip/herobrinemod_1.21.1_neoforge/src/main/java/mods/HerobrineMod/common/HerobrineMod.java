package mods.HerobrineMod.common;

import net.neoforged.bus.api.IEventBus;import net.neoforged.fml.ModContainer;import net.neoforged.fml.common.Mod;

@Mod(HerobrineMod.MOD_ID)
public final class HerobrineMod {
    public static final String MOD_ID="herobrinemod";public static final String VERSION="3.7";public static final ModConfig CONFIG=ModConfig.VALUES;
    public HerobrineMod(IEventBus bus,ModContainer container){ModBlocks.BLOCKS.register(bus);ModItems.ITEMS.register(bus);ModEntities.ENTITIES.register(bus);ModSounds.SOUNDS.register(bus);bus.addListener(HerobrineModEvents::attributes);container.registerConfig(net.neoforged.fml.config.ModConfig.Type.COMMON,ModConfig.SPEC);}
}
