package mods.HerobrineMod.common;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS=DeferredRegister.createBlocks(HerobrineMod.MOD_ID);
    public static final DeferredBlock<Block> TOTEM=BLOCKS.register("totem",()->new BlockHerobrine(Block.Properties.of().mapColor(MapColor.COLOR_BLACK).strength(3.0F,20.0F).sound(SoundType.STONE).lightLevel(s->3)));
    private ModBlocks(){}
}
