package mods.HerobrineMod.common;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

public final class EntityJetra extends EntityFighter {
    public EntityJetra(EntityType<? extends EntityFighter> t,Level l){super(t,l);}
}
