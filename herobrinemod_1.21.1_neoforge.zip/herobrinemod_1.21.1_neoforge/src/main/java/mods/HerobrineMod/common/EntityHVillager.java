package mods.HerobrineMod.common;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

public final class EntityHVillager extends EntityFighter {
    public EntityHVillager(EntityType<? extends EntityFighter> t,Level l){super(t,l);}
}
