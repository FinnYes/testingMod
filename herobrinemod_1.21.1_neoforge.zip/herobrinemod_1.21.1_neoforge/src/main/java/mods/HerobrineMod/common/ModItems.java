package mods.HerobrineMod.common;

import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS=DeferredRegister.createItems(HerobrineMod.MOD_ID);
    public static final DeferredItem<BlockItem> TOTEM=ITEMS.registerItem("totem",p->new BlockItem(ModBlocks.TOTEM.get(),p));
    public static final DeferredItem<ItemHDisc> ITS=ITEMS.registerItem("itsherobrine",ItemHDisc::new,new Item.Properties().stacksTo(1));
    public static final DeferredItem<ItemHDisc> SEE=ITEMS.registerItem("seeherobrine",ItemHDisc::new,new Item.Properties().stacksTo(1));
    private ModItems(){}
}
