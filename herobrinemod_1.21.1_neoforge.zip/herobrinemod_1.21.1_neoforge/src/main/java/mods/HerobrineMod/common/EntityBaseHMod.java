package mods.HerobrineMod.common;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public abstract class EntityBaseHMod extends Monster {
    protected EntityBaseHMod(EntityType<? extends Monster> t,Level l){super(t,l);setPersistenceRequired();}
    @Override protected void registerGoals(){goalSelector.addGoal(7,new LookAtPlayerGoal(this,Player.class,32F));goalSelector.addGoal(8,new RandomLookAroundGoal(this));}
}
