package mods.HerobrineMod.common;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public final class EntityStalker extends EntityBaseHMod {
    private int lifeTicks;
    private final int lifeSpan=30+new java.util.Random().nextInt(20);
    private boolean appeared;
    public EntityStalker(EntityType<? extends Monster> t,Level l){super(t,l);}
    @Override protected void registerGoals(){super.registerGoals();targetSelector.addGoal(1,new NearestAttackableTargetGoal<>(this,Player.class,true));}
    @Override protected void customServerAiStep(){super.customServerAiStep();var p=level().getNearestPlayer(this,300D);if(p==null)return;lookAt(p,30F,30F);if(!appeared){appeared=true;HerobrineStalker.freeze(p,12);}if(lifeTicks++>=lifeSpan){discard();return;}if(random.nextInt(20)==0)HerobrineStalker.randomScare(this,p);if(random.nextInt(250)==0)HerobrineStalker.Boss(level(),blockPosition());}
    @Override public boolean hurt(net.minecraft.world.damagesource.DamageSource s,float a){if(random.nextInt(5)==0&&s.getEntity() instanceof Player p)HerobrineStalker.throwplayer2(p,this,1.2D);return super.hurt(s,a);}
}
