package mods.HerobrineMod.common;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

@EventBusSubscriber(modid = HerobrineMod.MOD_ID, bus = EventBusSubscriber.Bus.GAME)
public final class HerobrineEvents {
    private static long ticks;
    private HerobrineEvents() {}

    @SubscribeEvent
    public static void serverTick(ServerTickEvent.Post e) {
        if (++ticks % 20 != 0) return;
        int seconds = Math.max(1, HerobrineMod.CONFIG.spawn.get());
        if (ticks % (seconds * 20L) != 0) return;
        for (ServerLevel level : e.getServer().getAllLevels()) {
            for (var player : level.players()) {
                if (player.isSpectator() || level.getDifficulty() == net.minecraft.world.Difficulty.PEACEFUL) continue;
                if (level.random.nextInt(12) != 0) continue;
                BlockPos pos = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, player.blockPosition().offset(level.random.nextInt(25) - 12, 0, level.random.nextInt(25) - 12));
                HerobrineStalker.spawn(level, level.random.nextInt(20) == 0 ? ModEntities.HGHOST.get() : ModEntities.STALKER.get(), pos);
            }
        }
    }
}
