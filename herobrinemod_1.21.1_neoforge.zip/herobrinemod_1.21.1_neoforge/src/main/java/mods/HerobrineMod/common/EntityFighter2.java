package mods.HerobrineMod.common;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

public final class EntityFighter2 extends EntityFighter {
    public EntityFighter2(EntityType<? extends EntityFighter> t,Level l){super(t,l);}
}
