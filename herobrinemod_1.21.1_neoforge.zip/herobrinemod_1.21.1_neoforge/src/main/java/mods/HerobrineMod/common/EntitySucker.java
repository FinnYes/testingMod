package mods.HerobrineMod.common;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;

public final class EntitySucker extends Monster {
    public EntitySucker(EntityType<? extends Monster> t, Level l) { super(t, l); setPersistenceRequired(); }
    @Override public void tick() {
        super.tick();
        if (level().isClientSide) return;
        if (level().getDifficulty() == net.minecraft.world.Difficulty.PEACEFUL) { discard(); return; }
        if (HerobrineMod.CONFIG.extremeRareMode.get() == 1 && random.nextInt(80) != 9) { discard(); return; }
        if (random.nextInt(130) == 0) HerobrineStalker.spawn(level(), ModEntities.HGHOST.get(), blockPosition().offset(0, 0, 3));
        if (random.nextInt(130) == 0) HerobrineStalker.spawn(level(), ModEntities.NORRIS.get(), blockPosition());
        if (random.nextBoolean()) HerobrineStalker.spawn(level(), ModEntities.STALKER.get(), blockPosition());
        else HerobrineStalker.spawn(level(), ModEntities.BUILDER.get(), blockPosition());
        if (HerobrineMod.CONFIG.pigbrine.get() == 1 && random.nextInt(100) == 0) HerobrineStalker.spawn(level(), ModEntities.PIG.get(), blockPosition());
        if (HerobrineMod.CONFIG.cowbrine.get() == 1 && random.nextInt(100) == 0) HerobrineStalker.spawn(level(), ModEntities.COW.get(), blockPosition());
        if (random.nextInt(100) == 0) HerobrineStalker.spawn(level(), ModEntities.CHICKEN.get(), blockPosition());
        discard();
    }
    @Override protected void registerGoals() {}
}
