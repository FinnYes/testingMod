package mods.HerobrineMod.common;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

public final class BlockHerobrine extends Block {
    public BlockHerobrine(Properties properties){super(properties);}
    @Override protected void randomTick(BlockState state,ServerLevel level,BlockPos pos,RandomSource random){
        if(random.nextInt(160)==0) level.playSound(null,pos,ModSounds.AMBIENT.get(),net.minecraft.sounds.SoundSource.HOSTILE,.5F,.9F+random.nextFloat()*.2F);
    }
}
