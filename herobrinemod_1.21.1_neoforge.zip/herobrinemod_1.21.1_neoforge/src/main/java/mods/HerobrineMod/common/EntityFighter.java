package mods.HerobrineMod.common;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class EntityFighter extends Monster {
    public EntityFighter(EntityType<? extends Monster> t,Level l){super(t,l);setPersistenceRequired();}
    @Override protected void registerGoals(){goalSelector.addGoal(2,new MeleeAttackGoal(this,1.05D,true));goalSelector.addGoal(7,new LookAtPlayerGoal(this,Player.class,16F));goalSelector.addGoal(8,new RandomLookAroundGoal(this));targetSelector.addGoal(1,new NearestAttackableTargetGoal<>(this,Player.class,true));}
}
