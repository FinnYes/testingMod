package mods.HerobrineMod.common;

import net.neoforged.neoforge.common.ModConfigSpec;

public final class ModConfig {
    public static final ModConfig VALUES;
    public static final ModConfigSpec SPEC;
    public final ModConfigSpec.IntValue spawnEnemyCircles, spawn, maxSpawn, minSpawn, prank, pigbrine, cowbrine;
    public final ModConfigSpec.IntValue placeFire, placeLava, placeBuildings, placeTraps, placeGlass, placeTnt, placeWater;
    public final ModConfigSpec.IntValue setPlayerOnFire, dropTorches, dropPlayerItems, roundhousekick, extremeRareMode;
    public final ModConfigSpec.IntValue updateReminder, showAdd, miniMode, noTotemMode, debugMode;
    private ModConfig(ModConfigSpec.Builder b) {
        b.push("general");
        spawnEnemyCircles=b.defineInRange("spawn_enemy_circles",1,0,1);
        spawn=b.defineInRange("spawn",30,1,3600);
        maxSpawn=b.defineInRange("max_spawn",7,1,32);
        minSpawn=b.defineInRange("min_spawn",2,1,32);
        prank=b.defineInRange("prank",0,0,1);
        pigbrine=b.defineInRange("pigbrine",1,0,1);
        cowbrine=b.defineInRange("cowbrine",1,0,1);
        placeFire=b.defineInRange("place_fire",1,0,1);
        placeLava=b.defineInRange("place_lava",1,0,1);
        placeBuildings=b.defineInRange("place_buildings",1,0,1);
        placeTraps=b.defineInRange("place_traps",1,0,1);
        placeGlass=b.defineInRange("place_glass",1,0,1);
        placeTnt=b.defineInRange("place_tnt",1,0,1);
        placeWater=b.defineInRange("place_water",1,0,1);
        setPlayerOnFire=b.defineInRange("set_player_on_fire",1,0,1);
        dropTorches=b.defineInRange("drop_torches",1,0,1);
        dropPlayerItems=b.defineInRange("drop_player_items_on_floor",0,0,1);
        roundhousekick=b.defineInRange("Roundhousekick",1,0,1);
        extremeRareMode=b.defineInRange("extremraremode",0,0,1);
        updateReminder=b.defineInRange("update_reminder",1,0,1);
        showAdd=b.defineInRange("show_add",1,0,1);
        miniMode=b.defineInRange("mini_mode",0,0,1);
        noTotemMode=b.defineInRange("no_totem_mode",0,0,1);
        debugMode=b.defineInRange("debug_mode",0,0,1);
        b.pop();
    }
    static {
        var p=new ModConfigSpec.Builder().configure(ModConfig::new);
        VALUES=p.getLeft(); SPEC=p.getRight();
    }
}
