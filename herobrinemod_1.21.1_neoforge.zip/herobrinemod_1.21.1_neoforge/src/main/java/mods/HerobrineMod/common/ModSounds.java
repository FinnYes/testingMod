package mods.HerobrineMod.common;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS=DeferredRegister.create(BuiltInRegistries.SOUND_EVENT,HerobrineMod.MOD_ID);
    public static final DeferredHolder<SoundEvent,SoundEvent> ITS=reg("record_itsherobrine");
    public static final DeferredHolder<SoundEvent,SoundEvent> SEE=reg("record_seeherobrine");
    public static final DeferredHolder<SoundEvent,SoundEvent> AMBIENT=reg("herobrine_ambient");
    private static DeferredHolder<SoundEvent,SoundEvent> reg(String id){return SOUNDS.register(id,()->SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(HerobrineMod.MOD_ID,id)));}
    private ModSounds(){}
}
