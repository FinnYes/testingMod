package mods.HerobrineMod.common;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public final class EntityBuilder extends EntityBaseHMod {
    private boolean built; private int lifeTicks;
    public EntityBuilder(EntityType<? extends EntityBaseHMod> t,Level l){super(t,l);}
    @Override protected void registerGoals(){super.registerGoals();targetSelector.addGoal(1,new NearestAttackableTargetGoal<>(this,Player.class,true));}
    @Override protected void customServerAiStep(){super.customServerAiStep();if(!built){built=true;if(HerobrineMod.CONFIG.placeBuildings.get()==1)HerobrineBuilder.placeRandom((net.minecraft.server.level.ServerLevel)level(),blockPosition(),false,random);else if(HerobrineMod.CONFIG.placeTraps.get()==1)HerobrineBuilder.placeRandom((net.minecraft.server.level.ServerLevel)level(),blockPosition(),true,random);HerobrineStalker.blastGlowe(level(),blockPosition());}if(++lifeTicks>40)discard();}
}
