package mods.HerobrineMod.common;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.sounds.SoundSource;

public final class ItemHDisc extends Item {
    public ItemHDisc(Properties p){super(p);}
    @Override public InteractionResultHolder<ItemStack> use(Level level,Player player,InteractionHand hand){
        ItemStack stack=player.getItemInHand(hand);
        if(!level.isClientSide){var sound=stack.is(ModItems.SEE.get())?ModSounds.SEE.get():ModSounds.ITS.get();level.playSound(null,player.blockPosition(),sound,SoundSource.RECORDS,1F,1F);player.getCooldowns().addCooldown(this,20);}
        return InteractionResultHolder.sidedSuccess(stack,level.isClientSide());
    }
}
