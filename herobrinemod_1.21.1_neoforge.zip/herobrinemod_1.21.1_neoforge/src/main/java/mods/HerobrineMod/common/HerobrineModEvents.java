package mods.HerobrineMod.common;

import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;

public final class HerobrineModEvents {
    private HerobrineModEvents() {}
    @SubscribeEvent
    public static void attributes(EntityAttributeCreationEvent e) {
        var humanoid = net.minecraft.world.entity.LivingEntity.createLivingAttributes()
                .add(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH, 10)
                .add(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED, .6)
                .add(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE, 3)
                .add(net.minecraft.world.entity.ai.attributes.Attributes.FOLLOW_RANGE, 32).build();
        var ghost = net.minecraft.world.entity.LivingEntity.createLivingAttributes()
                .add(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH, 20)
                .add(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED, .35)
                .add(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE, 4)
                .add(net.minecraft.world.entity.ai.attributes.Attributes.FOLLOW_RANGE, 32).build();
        var boss = net.minecraft.world.entity.LivingEntity.createLivingAttributes()
                .add(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH, 300)
                .add(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED, .35)
                .add(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE, 10)
                .add(net.minecraft.world.entity.ai.attributes.Attributes.FOLLOW_RANGE, 48).build();
        e.put(ModEntities.HGHOST.get(), ghost); e.put(ModEntities.STALKER.get(), humanoid); e.put(ModEntities.BUILDER.get(), humanoid);
        e.put(ModEntities.NORRIS.get(), humanoid); e.put(ModEntities.FIGHTER.get(), humanoid); e.put(ModEntities.FIGHTER2.get(), humanoid);
        e.put(ModEntities.HVILLAGER.get(), humanoid); e.put(ModEntities.JETRA.get(), humanoid); e.put(ModEntities.BOSS.get(), boss);
        e.put(ModEntities.ZOMBIE.get(), humanoid);
        e.put(ModEntities.SUCKER.get(), net.minecraft.world.entity.LivingEntity.createLivingAttributes().add(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH, 4).add(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED, .25).add(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE, 1).build());
        e.put(ModEntities.CHICKEN.get(), net.minecraft.world.entity.LivingEntity.createLivingAttributes().add(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH, 4).add(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED, .25).build());
        e.put(ModEntities.COW.get(), net.minecraft.world.entity.LivingEntity.createLivingAttributes().add(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH, 10).add(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED, .2).build());
        e.put(ModEntities.PIG.get(), net.minecraft.world.entity.LivingEntity.createLivingAttributes().add(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH, 10).add(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED, .25).build());
    }
}
