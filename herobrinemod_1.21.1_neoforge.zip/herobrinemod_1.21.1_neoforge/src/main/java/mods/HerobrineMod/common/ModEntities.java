package mods.HerobrineMod.common;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModEntities {
    public static final DeferredRegister.Entities ENTITIES=DeferredRegister.createEntities(HerobrineMod.MOD_ID);
    public static final DeferredHolder<EntityType<?>,EntityType<EntityHerobrine>> HGHOST=reg("hghost",EntityHerobrine::new,MobCategory.MONSTER,.6F,1.95F);
    public static final DeferredHolder<EntityType<?>,EntityType<EntityStalker>> STALKER=reg("herobrine_stalker",EntityStalker::new,MobCategory.MONSTER,.6F,1.95F);
    public static final DeferredHolder<EntityType<?>,EntityType<EntityBuilder>> BUILDER=reg("herobrine_builder",EntityBuilder::new,MobCategory.MONSTER,.6F,1.95F);
    public static final DeferredHolder<EntityType<?>,EntityType<EntityNorris>> NORRIS=reg("chuck_norris",EntityNorris::new,MobCategory.MONSTER,.6F,1.95F);
    public static final DeferredHolder<EntityType<?>,EntityType<EntityFighter>> FIGHTER=reg("herobrine",EntityFighter::new,MobCategory.MONSTER,.6F,1.95F);
    public static final DeferredHolder<EntityType<?>,EntityType<EntityFighter2>> FIGHTER2=reg("notch",EntityFighter2::new,MobCategory.MONSTER,.6F,1.95F);
    public static final DeferredHolder<EntityType<?>,EntityType<EntityHVillager>> HVILLAGER=reg("herobrine_slave",EntityHVillager::new,MobCategory.MONSTER,.6F,1.95F);
    public static final DeferredHolder<EntityType<?>,EntityType<EntityChicken2>> CHICKEN=reg("evilchicken",EntityChicken2::new,MobCategory.CREATURE,.4F,.7F);
    public static final DeferredHolder<EntityType<?>,EntityType<EntitySucker>> SUCKER=reg("hdummy",EntitySucker::new,MobCategory.MONSTER,.9F,1.3F);
    public static final DeferredHolder<EntityType<?>,EntityType<EntityCow2>> COW=reg("cowbrine",EntityCow2::new,MobCategory.CREATURE,.9F,1.4F);
    public static final DeferredHolder<EntityType<?>,EntityType<EntityPig2>> PIG=reg("pigbrine",EntityPig2::new,MobCategory.CREATURE,.9F,.9F);
    public static final DeferredHolder<EntityType<?>,EntityType<EntityHerobrineBoss>> BOSS=reg("herobrine_boss",EntityHerobrineBoss::new,MobCategory.MONSTER,1.0F,2.8F);
    public static final DeferredHolder<EntityType<?>,EntityType<EntityJetra>> JETRA=reg("jetra",EntityJetra::new,MobCategory.MONSTER,.6F,1.95F);
    public static final DeferredHolder<EntityType<?>,EntityType<EntityZombie2>> ZOMBIE=reg("herobrinezombie",EntityZombie2::new,MobCategory.MONSTER,.6F,1.95F);
    private static <T extends net.minecraft.world.entity.Mob> DeferredHolder<EntityType<?>,EntityType<T>> reg(String id,EntityType.EntityFactory<T> factory,MobCategory cat,float w,float h){return ENTITIES.register(id,()->EntityType.Builder.of(factory,cat).sized(w,h).build(id));}
    private ModEntities(){}
}
