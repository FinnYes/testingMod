package mods.HerobrineMod.client;

import mods.HerobrineMod.common.HerobrineMod;
import mods.HerobrineMod.common.ModEntities;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.ChickenRenderer;
import net.minecraft.client.renderer.entity.CowRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.PigRenderer;
import net.minecraft.client.renderer.entity.ZombieRenderer;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

@EventBusSubscriber(modid=HerobrineMod.MOD_ID,bus=EventBusSubscriber.Bus.MOD,value=Dist.CLIENT)
public final class HerobrineClient {
    private static ResourceLocation tex(String n){return ResourceLocation.fromNamespaceAndPath(HerobrineMod.MOD_ID,"textures/entity/"+n+".png");}
    private HerobrineClient(){}
    @SubscribeEvent public static void renderers(EntityRenderersEvent.RegisterRenderers e){
        e.registerEntityRenderer(ModEntities.HGHOST.get(),c->new HRenderer<>(c,tex("herobrine"),.4F,1F));
        e.registerEntityRenderer(ModEntities.STALKER.get(),c->new HRenderer<>(c,tex("herobrine"),.4F,1F));
        e.registerEntityRenderer(ModEntities.BUILDER.get(),c->new HRenderer<>(c,tex("herobrine"),.4F,1F));
        e.registerEntityRenderer(ModEntities.NORRIS.get(),c->new HRenderer<>(c,tex("chuck"),.4F,1F));
        e.registerEntityRenderer(ModEntities.FIGHTER.get(),c->new HRenderer<>(c,tex("herobrine"),.4F,1F));
        e.registerEntityRenderer(ModEntities.FIGHTER2.get(),c->new HRenderer<>(c,tex("notch"),.4F,1F));
        e.registerEntityRenderer(ModEntities.HVILLAGER.get(),c->new HRenderer<>(c,tex("hvillager"),.4F,1F));
        e.registerEntityRenderer(ModEntities.JETRA.get(),c->new HRenderer<>(c,tex("jetra"),.4F,1F));
        e.registerEntityRenderer(ModEntities.BOSS.get(),c->new HRenderer<>(c,tex("herobrine"),.7F,1.35F));
        e.registerEntityRenderer(ModEntities.SUCKER.get(),c->new HRenderer<>(c,tex("sucker"),.3F,.9F));
        e.registerEntityRenderer(ModEntities.CHICKEN.get(),HChickenRenderer::new);
        e.registerEntityRenderer(ModEntities.COW.get(),HCowRenderer::new);
        e.registerEntityRenderer(ModEntities.PIG.get(),HPigRenderer::new);
        e.registerEntityRenderer(ModEntities.ZOMBIE.get(),HZombieRenderer::new);
    }
    private static final class HRenderer<T extends net.minecraft.world.entity.Mob> extends HumanoidMobRenderer<T,HumanoidModel<T>>{
        private final ResourceLocation texture;
        HRenderer(EntityRendererProvider.Context c,ResourceLocation t,float shadow,float scale){super(c,new HumanoidModel<>(c.bakeLayer(ModelLayers.PLAYER)),shadow,scale,scale,scale);texture=t;}
        @Override public ResourceLocation getTextureLocation(T e){return texture;}
    }
    private static final class HChickenRenderer extends ChickenRenderer{HChickenRenderer(EntityRendererProvider.Context c){super(c);}@Override public ResourceLocation getTextureLocation(net.minecraft.world.entity.animal.Chicken e){return tex("angrychicken");}}
    private static final class HCowRenderer extends CowRenderer{HCowRenderer(EntityRendererProvider.Context c){super(c);}@Override public ResourceLocation getTextureLocation(net.minecraft.world.entity.animal.Cow e){return tex("cowbrine");}}
    private static final class HPigRenderer extends PigRenderer{HPigRenderer(EntityRendererProvider.Context c){super(c);}@Override public ResourceLocation getTextureLocation(net.minecraft.world.entity.animal.Pig e){return tex("pigbrine");}}
    private static final class HZombieRenderer extends ZombieRenderer{HZombieRenderer(EntityRendererProvider.Context c){super(c);}@Override public ResourceLocation getTextureLocation(net.minecraft.world.entity.monster.Zombie e){return tex("zombie");}}
}
