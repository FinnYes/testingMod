@echo off
where java >nul 2>nul || (echo Java 21 is required.& exit /b 1)
where gradle >nul 2>nul || (echo Gradle 9.x is required in PATH.& exit /b 1)
gradle build
