package com.herobrinemod;

import net.neoforged.neoforge.common.ModConfigSpec;

/**
 * Config file: config/herobrinemod-common.toml
 * Most options are carried over from the 1.7.10 mod; they are used by the mobs added in later stages.
 * (update_reminder and show_add were dropped on purpose.)
 */
public final class Config {
    private static final ModConfigSpec.Builder B = new ModConfigSpec.Builder();

    // ---- spawning ----
    public static final ModConfigSpec.BooleanValue SPAWN_ENEMY_CIRCLES;
    public static final ModConfigSpec.IntValue SPAWN_WEIGHT;
    public static final ModConfigSpec.IntValue MIN_SPAWN;
    public static final ModConfigSpec.IntValue MAX_SPAWN;
    public static final ModConfigSpec.BooleanValue PIGBRINE;
    public static final ModConfigSpec.BooleanValue COWBRINE;
    public static final ModConfigSpec.BooleanValue EXTREME_RARE_MODE;

    // ---- what Herobrine is allowed to do ----
    public static final ModConfigSpec.BooleanValue PLACE_FIRE;
    public static final ModConfigSpec.BooleanValue PLACE_LAVA;
    public static final ModConfigSpec.BooleanValue PLACE_BUILDINGS;
    public static final ModConfigSpec.BooleanValue PLACE_TRAPS;
    public static final ModConfigSpec.BooleanValue PLACE_GLASS;
    public static final ModConfigSpec.BooleanValue PLACE_TNT;
    public static final ModConfigSpec.BooleanValue PLACE_WATER;
    public static final ModConfigSpec.BooleanValue SET_PLAYER_ON_FIRE;
    public static final ModConfigSpec.BooleanValue DROP_TORCHES;
    public static final ModConfigSpec.BooleanValue DROP_PLAYER_ITEMS_ON_FLOOR;
    public static final ModConfigSpec.BooleanValue ROUNDHOUSE_KICK;

    // ---- modes ----
    public static final ModConfigSpec.BooleanValue PRANK;
    public static final ModConfigSpec.BooleanValue MINI_MODE;
    public static final ModConfigSpec.BooleanValue NO_TOTEM_MODE;
    public static final ModConfigSpec.BooleanValue DEBUG_MODE;

    static {
        B.push("spawning");
        SPAWN_ENEMY_CIRCLES = B.comment("Spawn circles of hostile animals around the player").define("spawn_enemy_circles", true);
        SPAWN_WEIGHT = B.comment("Spawn weight of Herobrine's 'sucker' mob").defineInRange("spawn", 30, 0, 1000);
        MIN_SPAWN = B.comment("Minimum group size. Must not be higher than max_spawn").defineInRange("min_spawn", 2, 1, 64);
        MAX_SPAWN = B.comment("Maximum group size").defineInRange("max_spawn", 7, 1, 64);
        PIGBRINE = B.comment("Enable Pigbrine").define("pigbrine", true);
        COWBRINE = B.comment("Enable Cowbrine").define("cowbrine", true);
        EXTREME_RARE_MODE = B.comment("Make Herobrine extremely rare").define("extremraremode", false);
        B.pop();

        B.push("actions");
        PLACE_FIRE = B.define("place_fire", true);
        PLACE_LAVA = B.define("place_lava", true);
        PLACE_BUILDINGS = B.define("place_buildings", true);
        PLACE_TRAPS = B.define("place_traps", true);
        PLACE_GLASS = B.define("place_glass", true);
        PLACE_TNT = B.define("place_tnt", true);
        PLACE_WATER = B.define("place_water", true);
        SET_PLAYER_ON_FIRE = B.define("set_player_on_fire", true);
        DROP_TORCHES = B.define("drop_torches", true);
        DROP_PLAYER_ITEMS_ON_FLOOR = B.define("drop_player_items_on_floor", true);
        ROUNDHOUSE_KICK = B.define("roundhouse_kick", true);
        B.pop();

        B.push("modes");
        PRANK = B.comment("Wanna troll your friends? Herobrine can always appear and no totem is needed").define("prank", false);
        MINI_MODE = B.define("mini_mode", false);
        NO_TOTEM_MODE = B.comment("Herobrine can appear without an active totem").define("no_totem_mode", false);
        DEBUG_MODE = B.define("debug_mode", false);
        B.pop();
    }

    public static final ModConfigSpec SPEC = B.build();

    private Config() {}
}
