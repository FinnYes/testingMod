package com.herobrinemod;

import com.herobrinemod.registry.ModBlocks;
import com.herobrinemod.registry.ModCreativeTabs;
import com.herobrinemod.registry.ModItems;
import com.herobrinemod.registry.ModSounds;
import com.mojang.logging.LogUtils;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import org.slf4j.Logger;

/**
 * The Herobrine Mod - port of Burnner's 1.7.10 mod to NeoForge 1.21.1.
 * Stage 1: skeleton, totem block, music discs, config, translations.
 */
@Mod(HerobrineMod.MODID)
public class HerobrineMod {
    public static final String MODID = "herobrinemod";
    public static final Logger LOGGER = LogUtils.getLogger();

    public HerobrineMod(IEventBus modBus, ModContainer modContainer) {
        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModSounds.SOUNDS.register(modBus);
        ModCreativeTabs.TABS.register(modBus);

        modContainer.registerConfig(ModConfig.Type.COMMON, Config.SPEC);

        modBus.addListener(this::commonSetup);
        NeoForge.EVENT_BUS.addListener((ServerStoppedEvent event) -> HerobrineState.clear());
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        // Tribute to the original mod's startup messages :)
        LOGGER.info("Herobrine Mod load()....");
        LOGGER.info("Hacking Minecraft.jar....");
        LOGGER.info("Injecting the herobrine virus....");
        LOGGER.info("Done, system successfully hacked!");
    }
}
