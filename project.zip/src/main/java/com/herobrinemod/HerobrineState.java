package com.herobrinemod;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.server.level.ServerLevel;

/**
 * Replacement for the old static "canSpawn" flag.
 * Herobrine may appear while at least one totem is active (or no_totem_mode / debug_mode / prank is on).
 * Active totems re-register themselves every few ticks, so the set refills after a world reload.
 */
public final class HerobrineState {
    private static final Set<GlobalPos> ACTIVE_TOTEMS = ConcurrentHashMap.newKeySet();

    private HerobrineState() {}

    public static void addTotem(ServerLevel level, BlockPos pos) {
        ACTIVE_TOTEMS.add(GlobalPos.of(level.dimension(), pos.immutable()));
    }

    public static void removeTotem(ServerLevel level, BlockPos pos) {
        ACTIVE_TOTEMS.remove(GlobalPos.of(level.dimension(), pos.immutable()));
    }

    public static void clear() {
        ACTIVE_TOTEMS.clear();
    }

    /** Used by the mobs in the next stages. */
    public static boolean canSpawn() {
        return Config.NO_TOTEM_MODE.get() || Config.PRANK.get() || Config.DEBUG_MODE.get() || !ACTIVE_TOTEMS.isEmpty();
    }
}
