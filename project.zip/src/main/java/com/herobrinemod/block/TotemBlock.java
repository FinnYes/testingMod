package com.herobrinemod.block;

import com.herobrinemod.HerobrineState;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.Vec3;

/**
 * Herobrine totem. Ritual (vertical, from the bottom):
 * gold block, gold block, TOTEM, netherrack, fire.
 * When complete: lightning strikes and Herobrine is allowed to appear.
 * (The old metadata/texture swap is now the ACTIVE block state.)
 */
public class TotemBlock extends Block {
    public static final MapCodec<TotemBlock> CODEC = simpleCodec(TotemBlock::new);
    public static final BooleanProperty ACTIVE = BooleanProperty.create("active");

    private static final int CHECK_INTERVAL = 10; // ticks

    public TotemBlock(BlockBehaviour.Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(ACTIVE, false));
    }

    @Override
    protected MapCodec<? extends Block> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(ACTIVE);
    }

    @Override
    protected void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean movedByPiston) {
        if (!level.isClientSide && !oldState.is(this)) {
            level.scheduleTick(pos, this, CHECK_INTERVAL);
        }
    }

    @Override
    protected void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        boolean ritualComplete = isRitualComplete(level, pos);
        boolean active = state.getValue(ACTIVE);

        if (ritualComplete) {
            HerobrineState.addTotem(level, pos);
            if (!active) {
                activate(state, level, pos);
            }
        } else if (active) {
            level.setBlock(pos, state.setValue(ACTIVE, false), Block.UPDATE_ALL);
            HerobrineState.removeTotem(level, pos);
        }

        level.scheduleTick(pos, this, CHECK_INTERVAL);
    }

    private void activate(BlockState state, ServerLevel level, BlockPos pos) {
        level.setBlock(pos, state.setValue(ACTIVE, true), Block.UPDATE_ALL);
        broadcast(level.getServer(), "You don't know what you did....");

        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt != null) {
            bolt.moveTo(Vec3.atBottomCenterOf(pos.above(2)));
            level.addFreshEntity(bolt);
        }
    }

    private static boolean isRitualComplete(Level level, BlockPos pos) {
        return level.getBlockState(pos.above(2)).is(Blocks.FIRE)
                && level.getBlockState(pos.above()).is(Blocks.NETHERRACK)
                && level.getBlockState(pos.below()).is(Blocks.GOLD_BLOCK)
                && level.getBlockState(pos.below(2)).is(Blocks.GOLD_BLOCK);
    }

    @Override
    public BlockState playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        if (!level.isClientSide) {
            broadcast(level.getServer(), "You will never be free....");
        }
        return super.playerWillDestroy(level, pos, state, player);
    }

    @Override
    protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && level instanceof ServerLevel serverLevel) {
            HerobrineState.removeTotem(serverLevel, pos);
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    private static void broadcast(MinecraftServer server, String message) {
        if (server != null) {
            server.getPlayerList().broadcastSystemMessage(Component.literal(message), false);
        }
    }
}
