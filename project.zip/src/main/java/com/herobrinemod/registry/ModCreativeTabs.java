package com.herobrinemod.registry;

import com.herobrinemod.HerobrineMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, HerobrineMod.MODID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup." + HerobrineMod.MODID))
                    .icon(() -> ModItems.TOTEM.get().getDefaultInstance())
                    .displayItems((parameters, output) -> {
                        output.accept(ModItems.TOTEM.get());
                        output.accept(ModItems.SEE_HEROBRINE_DISC.get());
                        output.accept(ModItems.ITS_HEROBRINE_DISC.get());
                    })
                    .build());

    private ModCreativeTabs() {}
}
