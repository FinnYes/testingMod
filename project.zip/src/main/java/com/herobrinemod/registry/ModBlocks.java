package com.herobrinemod.registry;

import com.herobrinemod.HerobrineMod;
import com.herobrinemod.block.TotemBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(HerobrineMod.MODID);

    public static final DeferredBlock<TotemBlock> TOTEM = BLOCKS.registerBlock("totem", TotemBlock::new,
            BlockBehaviour.Properties.of()
                    .mapColor(MapColor.STONE)
                    .strength(3.0F, 20.0F)
                    .sound(SoundType.STONE)
                    .requiresCorrectToolForDrops());

    private ModBlocks() {}
}
