package com.herobrinemod.registry;

import com.herobrinemod.HerobrineMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.JukeboxSong;
import net.minecraft.world.item.Rarity;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(HerobrineMod.MODID);

    // Jukebox songs are data-driven in 1.21: data/herobrinemod/jukebox_song/*.json
    public static final ResourceKey<JukeboxSong> SEE_HEROBRINE_SONG = songKey("seeherobrine");
    public static final ResourceKey<JukeboxSong> ITS_HEROBRINE_SONG = songKey("itsherobrine");

    public static final DeferredItem<BlockItem> TOTEM = ITEMS.registerSimpleBlockItem("totem", ModBlocks.TOTEM);

    public static final DeferredItem<Item> SEE_HEROBRINE_DISC = ITEMS.registerSimpleItem("seeherobrine",
            new Item.Properties().stacksTo(1).rarity(Rarity.RARE).jukeboxPlayable(SEE_HEROBRINE_SONG));

    public static final DeferredItem<Item> ITS_HEROBRINE_DISC = ITEMS.registerSimpleItem("itsherobrine",
            new Item.Properties().stacksTo(1).rarity(Rarity.RARE).jukeboxPlayable(ITS_HEROBRINE_SONG));

    private static ResourceKey<JukeboxSong> songKey(String name) {
        return ResourceKey.create(Registries.JUKEBOX_SONG, ResourceLocation.fromNamespaceAndPath(HerobrineMod.MODID, name));
    }

    private ModItems() {}
}
