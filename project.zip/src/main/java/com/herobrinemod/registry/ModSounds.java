package com.herobrinemod.registry;

import com.herobrinemod.HerobrineMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, HerobrineMod.MODID);

    public static final DeferredHolder<SoundEvent, SoundEvent> RECORD_SEE_HEROBRINE = register("record.seeherobrine");
    public static final DeferredHolder<SoundEvent, SoundEvent> RECORD_ITS_HEROBRINE = register("record.itsherobrine");

    private static DeferredHolder<SoundEvent, SoundEvent> register(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(
                ResourceLocation.fromNamespaceAndPath(HerobrineMod.MODID, name)));
    }

    private ModSounds() {}
}
